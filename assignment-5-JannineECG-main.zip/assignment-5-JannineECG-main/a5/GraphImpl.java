package a5;

import java.util.*;

public class GraphImpl implements Graph {
    Map<String, Node> nodes;//Do not delete.  Use this field to store your nodes.
    int numEdges;
    int numNodes;// key: name of node. value: a5.Node object associated with name

    public GraphImpl() {
        nodes = new HashMap<>();
        this.numEdges = 0;
        this.numNodes = 0;
    }


    @Override
    public boolean addNode(String name) {
        boolean n = nodes.containsKey(name);
        if (name == null || n) {
            return false;
        } else {
        Node value = new NodeImpl(name);
        nodes.put(name, value);
        this.numNodes ++;
        return true;
        }

    }

    @Override
    public boolean addEdge(String src, String dest, double weight) {
        boolean s = nodes.containsKey(src);
        boolean d = nodes.containsKey(dest);
        if (src == dest) {
            return false;
        }
        if (weight < 0) {
            return false;
        }
        if (src == null || dest == null) {
            return false;
        }
        if (!s || !d) {
            return false;
        }
        if (nodes.get(src).connected(dest)) {
            return false;
        }
        EdgeImpl toAdd = new EdgeImpl(src, dest, weight);
        this.numEdges++;
        nodes.get(dest).getEdges().add(toAdd);

        return true;  //Dummy return value.  Remove when you implement!
    }

    public void printer() {
        for (Node n : nodes.values()) {
            System.out.println(n.getName());
            for (EdgeImpl e : n.getEdges()) {
                System.out.println("\t" + n.getName() + "-->" + e.destination);
            }
        }
    }

    @Override
    public boolean deleteNode(String name) {
        //Hint: Do you need to remove edges when you delete a node?
        boolean no = nodes.containsKey(name);
        if (!no) {
            return false;
        }
        ArrayList<EdgeImpl> del = new ArrayList<>();
        for (Node n : nodes.values()) {
            for (EdgeImpl e : n.getEdges()) {
                if (e.source.equals(name)) {
                    del.add(e);
                }
            }

        }
        for (EdgeImpl e : del) {
            deleteEdge(e.source, e.destination);
        }
        nodes.remove(name);
        this.numNodes--;
        return true;  //Dummy return value.  Remove when you implement!
    }

    @Override
    public boolean deleteEdge(String src, String dest) {
        boolean s = nodes.containsKey(src);
        boolean d = nodes.containsKey(dest);
        if (src == null || dest == null) {
            return false;
        }
        if (!s || !d) {
            return false;
        }
        if (!nodes.get(dest).connected(src)) {
            return false;
        }
        Node destination = nodes.get(dest);
        destination.delEdge(src);
        this.numEdges--;
        return true;
        //Dummy return value.  Remove when you implement!
    }

    @Override
    public int numNodes() {
        return numNodes;  //Dummy return value.  Remove when you implement!
    }

    @Override
    public int numEdges() {
        return numEdges;  //Dummy return value.  Remove when you implement!
    }


    @Override
    public Stack<String> topoSort() {
        HashMap<String, Node> same = new HashMap<>(this.nodes);
        same.putAll(this.nodes);
        Stack<String> topo = new Stack<>();
        List<String> zeroNodes = new ArrayList<>();
        Map<String, Node> toSort = nodes;

        while (true) {
            boolean zeroFound = false;
            for (Map.Entry<String, Node> node : toSort.entrySet()) { // go through all edges
                Node aNode = node.getValue();
                if (aNode.getEdges().size() == 0) { // if a node has 0 inEdges
                    zeroNodes.add(aNode.getName());
                    zeroFound = true;
                }
            }

            for (String label : zeroNodes) { // add 0-inDegree nodes to the topo sorted arraylist
                topo.add(label);
                this.deleteNode(label);
            }
            zeroNodes.clear();


            if (!zeroFound) {
                if (toSort.size() != 0) {
                    Stack<String> none = new Stack<>();
                    return none ; // no more zeros: done or cycle is acyclic
                } else {
                    nodes = same; // restore original graph

                }
                return topo;
            }
        }
    }
}
