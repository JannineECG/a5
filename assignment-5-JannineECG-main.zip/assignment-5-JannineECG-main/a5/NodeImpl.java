package a5;
import java.util.ArrayList;


public class NodeImpl implements Node {
    String name;
    ArrayList<EdgeImpl> edges;

    /*private ArrayList<Node> forwardNodes() {
        return null;
    }*/
    /* You will include the method signatures (return type, name, and arg types) for any node methods you
    need in this file. */

    /*Hint: Make sure you update the Node interface in Node.java when you add a new method implementation
    in NodeImpl.java, and vice-versa.  getName() in Node.java and NodeImpl.java is an example.  Also, files in
    previous homeworks (e.g., BST.java and BSTImpl.java in homework 3) are good examples of
    interfaces and their implementations.
     */

    /*Also, any node fields you want to add for the object should go in this file.  */

    /*@Override */
    public NodeImpl(String name){
        this.name= name;
        this.edges = new ArrayList<EdgeImpl>();
    }


    public String getName() {
        return this.name;//Dummy return value.  Remove when you implement!
    }

    @Override
    public ArrayList<EdgeImpl> getEdges() {
        return this.edges;
    }

    @Override
    public boolean connected(String diff) {
        if (diff == null){return false;}
        for(int i = 0; i <this.edges.size(); i++){
            if(edges.get(i).destination.equals(diff)){return true;}
        }
        return false;
    }

    @Override
    public void delEdge(String diff) {
        if(diff == null){return;}
        if (connected(diff)) {
            int del = -1;
            for(int i = 0; i< this.edges.size(); i++){
                if(edges.get(i).destination.equals(diff)){ del = i;}
            }
            this.getEdges().remove(del);
        }
    }
}
