package a5;

public class Main {


    public static void main(String[] args) {

        //You are encouraged (but not required) to include your testing code here.

        //Hint: Try to test basic operations (e.g., adding a few nodes and edges to graphs)
        //before you implement more complex methods\
        GraphImpl test = new GraphImpl();
        test.addNode("F");
        test.addNode("C");
        test.addNode("D");
        test.addNode("E");
        test.addNode("B");
        test.addNode("A");
        test.addEdge("F","A", 1.000);
        test.addEdge("F","C", 1.000);
        test.addEdge("E","A", 1.000);
        test.addEdge("E", "B", 1.000);
        test.addEdge("C","D", 1.000);
        test.addEdge("D", "B", 1.000);
        test.deleteEdge("E", "A");
        test.topoSort();
        test.numNodes();
        test.numEdges();
        test.printer();

        /*test.deleteNode("c");*/
        /*test.addEdge("a", "b", 2);
        test.addEdge("a", "c", 2);
        test.addEdge("c", "d", 2);
        test.topoSort();*/
        /*
CALL: addEdge
sourceName: E, destinationName: B, weight: 0.000000
CALL: addEdge
sourceName: C, destinationName: D, weight: 0.000000
CALL: addEdge
sourceName: D, destinationName: B, weight: 0.000000
CALL: topoSort

Node: A
    InLinks: F -> A, E -> A,
    OutLinks:

Node: B
    InLinks: E -> B, D -> B,
    OutLinks:

Node: C
    InLinks: F -> C,
    OutLinks: C -> D,

Node: D
    InLinks: C -> D,
    OutLinks: D -> B,

Node: E
    InLinks:
    OutLinks: E -> A, E -> B,

Node: F
    InLinks:
    OutLinks: F -> A, F -> C,

CALL: numNodes*/
    }

}
